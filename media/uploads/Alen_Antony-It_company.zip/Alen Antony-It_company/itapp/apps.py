from django.apps import AppConfig


class ItappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'itapp'
