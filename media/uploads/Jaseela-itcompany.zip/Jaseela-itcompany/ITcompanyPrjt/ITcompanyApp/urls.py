from django.urls import path,include
from.import views

urlpatterns = [
    path('', views.index, name='index'),
      path('log', views.log, name='log'),
        path('sinin', views.sinin, name='sinin'),
          path('book', views.book, name='book'),
           path('books', views.books, name='books'),
            path('home', views.home, name='home'),
]