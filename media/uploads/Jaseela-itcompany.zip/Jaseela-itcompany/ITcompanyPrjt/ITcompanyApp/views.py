

# Create your views here
from django.shortcuts import render,redirect
from django.contrib import messages
from django.utils.text import capfirst
from django.contrib.auth.models import User,auth
from .models import *
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.conf import settings



def index(request):

    return render(request,'home.html')
def  log(request):
    return render(request,'login.html')
def  sinin(request):
    return render(request,'register.html')
def  book(request):
    return render(request,'courseReg.html')
def  books(request):
    messages.success(request,'successfully registered')
    return render(request,'courseReg.html')
def home(request):
    return render(request,'home.html')