from django.apps import AppConfig


class StudyAbroadAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'study_abroad_app'
