from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'home.html')

def electronics(request):
    return render(request,'electronics.html')

def fashion(request):
    return render(request,'fashion.html')

def watche_ornaments(request):
    return render(request,'jewels.html')

def mens_fashion(request):
    return render(request,'gents.html')

def womens_fashion(request):
    return render(request,'women.html')

def lap_desktop(request):
    return render(request,'laptop.html')


def mobile(request):
    return render(request,'mobile.html')

def  home_app(request):
    return render(request,'homeapliance.html')

def log_in(request):
    return render(request,'login.html')

def sign_in(request):
    return render(request,'signin.html')

def about(request):
    return render(request,'about.html')

def cart(request):
    return render(request,'cart.html')