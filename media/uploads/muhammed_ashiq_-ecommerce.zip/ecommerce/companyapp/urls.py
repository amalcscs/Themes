from django.urls import path
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('electronics',views.electronics,name='electronics'),
    path('fashion',views.fashion,name='fashion'),
    path('watche_ornaments',views.watche_ornaments,name='watche_ornaments'),
    path('mens_fashion',views.mens_fashion,name='mens_fashion'),
    path('womens_fashion',views.womens_fashion,name='womens_fashion'),
    path('mobile',views.mobile,name='mobile'),
    path('home_app',views.home_app,name='home_app'),
    path('lap_desktop',views.lap_desktop,name='lap_desktop'),
    path('log_in',views.log_in,name='log_in'),
    path('sign_in',views.sign_in,name='sign_in'),
    path('about',views.about,name='about'),
    path('cart',views.cart,name='cart'),

]