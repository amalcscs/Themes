from django.urls import path,include
from . import views
urlpatterns=[
    path('',views.index,name='index'),
    path('loginpage',views.loginpage,name='loginpage'),
    path('appoinment',views.appoinment,name='appoinment'),
    path('register',views.register,name='register'),
    path('logout',views.logout,name='logout'),
    path('sign',views.sign,name='sign'),
]