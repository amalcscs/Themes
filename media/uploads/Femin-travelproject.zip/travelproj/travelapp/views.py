from django.shortcuts import render


# Create your views here.

def home(request):
    return render(request,'home.html')   

def login1(request):
    return render(request,'login1.html')  

def bookonline(request):
    return render(request,'bookonline.html')  
def booknow(request):
    return render(request,'booknow.html')  
def bookticket(request):
    return render(request,'bookticket.html') 
def signin(request):
    return render(request,'signin.html') 