from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('login1',views.login1,name='login1'),
    path('bookonline',views.bookonline,name='bookonline'),
    path('booknow',views.booknow,name='booknow'),
    path('bookticket',views.bookticket,name='bookticket'),
    path('signin',views.signin,name='signin'),
]