from django.apps import AppConfig


class ConstructionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'construction_app'
