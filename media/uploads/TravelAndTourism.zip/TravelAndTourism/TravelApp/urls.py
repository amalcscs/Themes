from django import views
from django.urls import path
from.import views
urlpatterns = [
    path('',views.home,name='home'),
   
    path('usercreate',views.usercreate,name='usercreate'),
    path('SLogin',views.SLogin,name='SLogin'),
    path('log',views.log,name='log'),
    path('sinin',views.sinin,name='sinin'),
    path('book',views.book,name='book'),
     path('ht',views.ht,name='ht'),
      path('htt',views.htt,name='htt'),
      path('uk',views.uk,name='uk'),
]