from django.apps import AppConfig


class TradersappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tradersApp'
