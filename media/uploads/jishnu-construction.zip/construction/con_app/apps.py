from django.apps import AppConfig


class ConAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'con_app'
