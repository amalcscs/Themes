from . import views
from django.urls import path

urlpatterns = [
    path('',views.home1,name='home1'),
    path('login',views.login,name='login'),
    path('home',views.home,name='home'),
    path('signup',views.signup,name='signup'),
    path('offer',views.offer,name='offer'),
    path('cata',views.cata,name='cata'),
     path('offer1',views.offer1,name='offer1'),
    path('cata1',views.cata1,name='cata1'),

    path('skin',views.skin,name='skin'),
    path('hair',views.hair,name='hair'),
    path('makeup',views.makeup,name='makeup'),
     path('skin1',views.skin1,name='skin1'),
    path('hair1',views.hair1,name='hair1'),
    path('makeup1',views.makeup1,name='makeup1'),
    path('about',views.about,name='about'),
    path('addtocart',views.addtocart,name='addtocart'),
    path('checkout',views.checkout,name='checkout'),
    path('lakme',views.lakme,name='lakme'),
    path('loreal',views.loreal,name='loreal'),
    path('foxt',views.foxt,name='foxt'),
    path('lakme1',views.lakme1,name='lakme1'),
    path('loreal1',views.loreal1,name='loreal1'),
    path('foxt1',views.foxt1,name='foxt1'),
    path('contact',views.contact,name='contact'),
    path('msg',views.msg,name='msg'),
    path('aboutus',views.aboutus,name='aboutus'),
    path('account',views.account,name='account'),
    path('whishlist',views.whishlist,name='whishlist'),
]