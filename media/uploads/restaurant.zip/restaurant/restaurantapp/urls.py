from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('contact',views.contact,name="contact"),
    path('reservation',views.reservation,name="reservation"),
    path('about',views.about,name="about"),
    path('services',views.services,name="services"),
    path('menu',views.menu,name="menu"),
]